To run the scheduler, extract all of the files from the zipped folder and double click on "MEScheduler.jar."

The program requires the Java JRE, which can be downloaded from http://www.java.com/en/download/ if you do not already have it installed.